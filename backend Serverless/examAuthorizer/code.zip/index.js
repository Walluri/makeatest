const jwt = require("jsonwebtoken");

exports.handler = async (event) => {
  //1 Extract the authorization token
  let token = event["authorizationToken"];

  //2 Extract the email information from the token
  let email = jwt.verify(token, config.get("jwtsecret123"));

  console.log(`authorizer invoked : ${email}`);

  //3 Determine of the person is allowed to access it or not
  //4 appropriately construct a policy document that allows or denies
  let permission = "Deny";
  //permission = (event["authorizationToken"] === "abc123") ? "Allow" : "Deny";
  permission =
    email === "prakash4455@gmail.com" || email === "portfoliookati@gmail.com"
      ? "Allow"
      : "Deny";
  // Extract the token
  // Extract the email
  // Check for email in DB
  // - Exists : allow access
  // - Does not exist : deny
  // Any way of passing the email to -> target resource apigateway or lambda
  //let userEmail = "prakash4455@gmail.com";
  const policyDocumentToReturn = {
    principalId: email,
    policyDocument: {
      Version: "2012-10-17",
      Statement: [
        {
          Action: "execute-api:Invoke",
          Resource: "*",
          Effect: permission,
        },
      ],
      //{apiId}/{stage}/{httpVerb}/[{resource}/[{child-resources}]]
    },
    //     context: {
    //     customKey: 'valluri',
    //   },
  };
  console.log(policyDocumentToReturn);
  return policyDocumentToReturn;
};

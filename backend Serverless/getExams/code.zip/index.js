const jwt = require("jsonwebtoken");

const headers = {
  "Access-Control-Allow-Headers": "Content-Type:application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
};

exports.handler = async (event) => {
  //const bodyObj = JSON.parse(event.body);
  //let idToken = bodyObj["tokenid"];
  let token = event.headers["x-auth-token"];
  if (token) {
    let user = jwt.verify(token, "jwtsecret123#");
  }

  try {
    const response = {
      statusCode: 200,
      headers,
      body: JSON.stringify({ route: "get tests", user }),
    };

    return response;
  } catch (err) {
    return {
      statusCode: 501,
      headers,
      body: JSON.stringify(`Internal Error Occured`),
    };
  }
};
